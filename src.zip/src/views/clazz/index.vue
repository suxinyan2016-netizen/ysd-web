<script setup>

</script>

<template>
  班级管理
</template>

<style scoped>

</style>