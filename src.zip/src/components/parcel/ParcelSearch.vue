<template>
  <div class="container">
    <el-form :inline="true" :model="searchParams" class="demo-form-inline">
      <el-form-item label="PackageNo">
        <el-input
          v-model="searchParams.packageNo"
          placeholder="PackageNo"
          style="width: 220px"
        />
      </el-form-item>

      <el-form-item label="Status" style="min-width: 150px">
        <el-select
          v-model="searchParams.status"
          placeholder="Choose"
          style="width: 100%"
        >
          <el-option label="Planed" value="0" />
          <el-option label="InDelivery" value="1" />
          <el-option label="Received" value="2" />
          <el-option label="Exception" value="9" />
        </el-select>
      </el-form-item>

      <el-form-item label="Item#">
        <el-input v-model="searchParams.itemNo" placeholder="Item#" />
      </el-form-item>

      <el-form-item label="SellerPart#">
        <el-input v-model="searchParams.sellerPart" placeholder="SellerPart#" />
      </el-form-item>
      <el-form-item label="ProcessID ">
        <el-input
          v-model="searchParams.processId"
          placeholder="ProcessId"
          style="width: 220px"
        />
      </el-form-item>

      <el-form-item label="ProcessDate">
        <el-date-picker
          v-model="searchParams.processDate"
          type="daterange"
          range-separator="to"
          start-placeholder="Start"
          end-placeholder="End"
          value-format="YYYY-MM-DD"
        />
      </el-form-item>

      <el-form-item label="Owner">
        <el-input
          v-model="searchParams.owner"
          placeholder="Owner"
          style="width: 120px"
        />
      </el-form-item>

      <el-form-item label="CreateDate">
        <el-date-picker
          v-model="searchParams.createDate"
          type="daterange"
          range-separator="to"
          start-placeholder="Start"
          end-placeholder="End"
          value-format="YYYY-MM-DD"
        />
      </el-form-item>

      <el-form-item label="From Who">
        <el-input
          v-model="searchParams.sender"
          placeholder="Sender#"
          style="width: 120px"
        />
      </el-form-item>

      <el-form-item label="SendDate">
        <el-date-picker
          v-model="searchParams.sendDate"
          type="daterange"
          range-separator="to"
          start-placeholder="Start"
          end-placeholder="End"
          value-format="YYYY-MM-DD"
        />
      </el-form-item>

      <el-form-item label="To Who">
        <el-input
          v-model="searchParams.receiver"
          placeholder="Receiver#"
          style="width: 120px"
        />
      </el-form-item>

      <el-form-item label="ReceivedDate">
        <el-date-picker
          v-model="searchParams.receivedDate"
          type="daterange"
          range-separator="to"
          start-placeholder="Start"
          end-placeholder="End"
          value-format="YYYY-MM-DD"
        />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="handleSearch">Search</el-button>
        <el-button type="info" @click="handleClear">Clean</el-button>
        <slot name="extra-actions"></slot>
      </el-form-item>
    </el-form>
  </div>
</template>

<script setup>
const props = defineProps({
  searchParams: {
    type: Object,
    required: true,
    default: () => ({})
  }
})

const emit = defineEmits(['search', 'clear'])

const handleSearch = () => {
  emit('search')
}

const handleClear = () => {
  emit('clear')
}
</script>

<style scoped>
.container {
  margin: 10px 0px;
}
</style>