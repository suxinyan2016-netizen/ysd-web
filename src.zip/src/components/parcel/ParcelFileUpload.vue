<template>
  <!-- 图片上传区域 -->
  <el-row :gutter="20">
    <!-- 发件前外观图片 -->
    <el-col :span="8">
      <el-form-item label="发件前外观">
        <el-upload
          class="avatar-uploader"
          :action="getUploadConfig('PACKAGE_SENDER')?.action"
          :headers="getUploadConfig('PACKAGE_SENDER')?.headers"
          :data="getUploadConfig('PACKAGE_SENDER')?.data"
          :show-file-list="false"
          :on-success="(res) => handleUploadSuccess(res, 'PACKAGE_SENDER')"
          :before-upload="(file) => beforeUpload(file, 'image')"
          :on-error="handleUploadError"
          :with-credentials="getUploadConfig('PACKAGE_SENDER')?.withCredentials"
        >
          <div class="upload-preview">
            <img
              v-if="getFirstImage('PACKAGE_SENDER')"
              :src="getFirstImage('PACKAGE_SENDER')"
              class="upload-image"
              @click.stop="previewImage(getFirstImage('PACKAGE_SENDER'))"
            />
            <div v-else class="upload-placeholder">
              <el-icon><Camera /></el-icon>
              <span>上传图片</span>
            </div>
          </div>
        </el-upload>
        <div v-if="getAttachments('PACKAGE_SENDER').length > 0" class="image-info">
          <span class="image-count">已上传: {{ getAttachments('PACKAGE_SENDER').length }} 张</span>
          <el-button
            v-if="getAttachments('PACKAGE_SENDER').length > 0"
            type="danger"
            size="small"
            @click="deleteAllAttachments('PACKAGE_SENDER')"
          >
            清空
          </el-button>
        </div>
      </el-form-item>
    </el-col>

    <!-- 收件后外观图片 -->
    <el-col :span="8">
      <el-form-item label="收件后外观">
        <el-upload
          class="avatar-uploader"
          :action="getUploadConfig('PACKAGE_RECEIVER')?.action"
          :headers="getUploadConfig('PACKAGE_RECEIVER')?.headers"
          :data="getUploadConfig('PACKAGE_RECEIVER')?.data"
          :show-file-list="false"
          :on-success="(res) => handleUploadSuccess(res, 'PACKAGE_RECEIVER')"
          :before-upload="(file) => beforeUpload(file, 'image')"
          :on-error="handleUploadError"
          :with-credentials="getUploadConfig('PACKAGE_RECEIVER')?.withCredentials"
        >
          <div class="upload-preview">
            <img
              v-if="getFirstImage('PACKAGE_RECEIVER')"
              :src="getFirstImage('PACKAGE_RECEIVER')"
              class="upload-image"
              @click.stop="previewImage(getFirstImage('PACKAGE_RECEIVER'))"
            />
            <div v-else class="upload-placeholder">
              <el-icon><Camera /></el-icon>
              <span>上传图片</span>
            </div>
          </div>
        </el-upload>
        <div v-if="getAttachments('PACKAGE_RECEIVER').length > 0" class="image-info">
          <span class="image-count">已上传: {{ getAttachments('PACKAGE_RECEIVER').length }} 张</span>
          <el-button
            v-if="getAttachments('PACKAGE_RECEIVER').length > 0"
            type="danger"
            size="small"
            @click="deleteAllAttachments('PACKAGE_RECEIVER')"
          >
            清空
          </el-button>
        </div>
      </el-form-item>
    </el-col>

    <!-- 包裹标签 -->
    <el-col :span="8">
      <el-form-item label="包裹标签">
        <el-upload
          class="avatar-uploader"
          :action="getUploadConfig('PACKAGE_LABEL')?.action"
          :headers="getUploadConfig('PACKAGE_LABEL')?.headers"
          :data="getUploadConfig('PACKAGE_LABEL')?.data"
          :show-file-list="false"
          :on-success="(res) => handleUploadSuccess(res, 'PACKAGE_LABEL')"
          :before-upload="(file) => beforeUpload(file, 'label')"
          :on-error="handleUploadError"
          :with-credentials="getUploadConfig('PACKAGE_LABEL')?.withCredentials"
        >
          <div class="upload-preview">
            <template v-if="getFirstImage('PACKAGE_LABEL')">
              <img
                v-if="isPdfFile(getFirstImage('PACKAGE_LABEL'))"
                src="@/assets/pdf-icon.png"
                class="upload-image"
                @click.stop="previewImage(getFirstImage('PACKAGE_LABEL'))"
              />
              <img
                v-else
                :src="getFirstImage('PACKAGE_LABEL')"
                class="upload-image"
                @click.stop="previewImage(getFirstImage('PACKAGE_LABEL'))"
              />
            </template>
            <div v-else class="upload-placeholder">
              <el-icon><Document /></el-icon>
              <span>上传标签</span>
            </div>
          </div>
        </el-upload>
        <div v-if="getAttachments('PACKAGE_LABEL').length > 0" class="image-info">
          <span class="image-count">已上传: {{ getAttachments('PACKAGE_LABEL').length }} 个</span>
          <el-button
            v-if="getAttachments('PACKAGE_LABEL').length > 0"
            type="danger"
            size="small"
            @click="deleteAllAttachments('PACKAGE_LABEL')"
          >
            清空
          </el-button>
        </div>
      </el-form-item>
    </el-col>
  </el-row>

  <!-- 打包单上传 -->
  <el-row :gutter="20">
    <el-col :span="24">
      <el-form-item label="装箱单">
        <el-upload
          class="packing-list-upload"
          :action="getUploadConfig('PACKING_LIST')?.action"
          :headers="getUploadConfig('PACKING_LIST')?.headers"
          :data="getUploadConfig('PACKING_LIST')?.data"
          :multiple="true"
          :show-file-list="false"
          :on-success="(res) => handleUploadSuccess(res, 'PACKING_LIST')"
          :before-upload="(file) => beforeUpload(file, 'packing')"
          :on-error="handleUploadError"
          :with-credentials="getUploadConfig('PACKING_LIST')?.withCredentials"
        >
          <el-button type="primary" plain>
            <el-icon><Plus /></el-icon> 添加装箱单文件
          </el-button>
          <div class="upload-tip">支持图片和PDF格式</div>
        </el-upload>
        
        <!-- 已上传文件列表 -->
        <div v-if="getAttachments('PACKING_LIST').length > 0" class="file-list">
          <div class="file-list-header">
            <span>已上传文件: {{ getAttachments('PACKING_LIST').length }} 个</span>
            <el-button
              type="danger"
              size="small"
              @click="deleteAllAttachments('PACKING_LIST')"
            >
              清空全部
            </el-button>
          </div>
          <div class="attachment-list">
            <div 
              v-for="attachment in getAttachments('PACKING_LIST')" 
              :key="attachment.id"
              class="attachment-item"
            >
              <div class="attachment-preview" @click="previewImage(attachment.imageUrl)">
                <el-icon v-if="isPdfFile(attachment.mimeType)">
                  <Document />
                </el-icon>
                <el-icon v-else>
                  <Picture />
                </el-icon>
              </div>
              <div class="attachment-details">
                <div class="attachment-name">{{ attachment.originalName }}</div>
                <div class="attachment-meta">
                  <span>{{ formatFileSize(attachment.fileSize) }}</span>
                  <span>{{ getFileType(attachment.mimeType) }}</span>
                </div>
              </div>
              <el-button
                type="danger"
                size="small"
                circle
                @click="deleteAttachment(attachment.id)"
              >
                <el-icon><Delete /></el-icon>
              </el-button>
            </div>
          </div>
        </div>
      </el-form-item>
    </el-col>
  </el-row>
</template>

<script setup>
import { Camera, Document, Delete, Plus, Picture } from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";
import { useFileUpload } from '@/composables/useFileUpload';

const props = defineProps({
  parcel: {
    type: Object,
    required: true,
  },
  token: {
    type: String,
    required: true,
  },
  currentUser: {
    type: Object,
    required: true,
  },
});

const emit = defineEmits(["preview-file"]);

// 使用 useFileUpload
const { imageManager, createUploadConfig } = useFileUpload(
  () => props.parcel,
  () => props.token,
  () => props.currentUser
);

// 获取上传配置
const getUploadConfig = (imageType) => {
  return createUploadConfig(imageType);
};

// 获取特定类型的附件
const getAttachments = (imageType) => {
  return imageManager?.getImagesByType?.(imageType) || [];
};

// 获取第一张图片的URL
const getFirstImage = (imageType) => {
  const attachments = getAttachments(imageType);
  if (attachments.length > 0) {
    return getFullImageUrl(attachments[0].imageUrl);
  }
  return '';
};

// 获取完整图片URL
const getFullImageUrl = (url) => {
  if (!url) return '';
  if (url.startsWith('http')) return url;
  return `http://localhost:8080${url}`;
};

// 文件类型判断
const isPdfFile = (mimeTypeOrUrl) => {
  if (typeof mimeTypeOrUrl === 'string') {
    return mimeTypeOrUrl.includes('.pdf') || mimeTypeOrUrl === 'application/pdf';
  }
  return false;
};

// 格式化文件大小
const formatFileSize = (bytes) => {
  if (!bytes) return '0 B';
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
};

// 获取文件类型
const getFileType = (mimeType) => {
  if (!mimeType) return '文件';
  if (mimeType.startsWith('image/')) return '图片';
  if (mimeType === 'application/pdf') return 'PDF';
  return '文件';
};

// 上传前验证
const beforeUpload = (file, type) => {
  // 检查文件大小
  const maxSize = type === 'image' ? 5 : 10; // MB
  const isLtSize = file.size / 1024 / 1024 < maxSize;
  
  if (!isLtSize) {
    ElMessage.error(`文件大小不能超过${maxSize}MB`);
    return false;
  }
  
  // 检查文件类型
  let isValidType = false;
  if (type === 'image') {
    isValidType = file.type.startsWith('image/');
  } else if (type === 'label') {
    isValidType = file.type.startsWith('image/') || file.type === 'application/pdf';
  } else if (type === 'packing') {
    isValidType = file.type.startsWith('image/') || file.type === 'application/pdf';
  }
  
  if (!isValidType) {
    ElMessage.error(`不支持的文件类型: ${file.type}`);
    return false;
  }
  
  return true;
};

// 上传成功处理
const handleUploadSuccess = (response, imageType) => {
  if (response.code === 1) {
    ElMessage.success('上传成功');
    
    // 刷新附件列表
    if (imageManager?.loadGroupedImages) {
      imageManager.loadGroupedImages();
    }
  } else {
    ElMessage.error(response.msg || '上传失败');
  }
};

// 删除单个附件
const deleteAttachment = async (attachmentId) => {
  try {
    await imageManager.deleteImage(attachmentId, true);
    ElMessage.success('删除成功');
  } catch (error) {
    ElMessage.error('删除失败');
  }
};

// 删除所有附件
const deleteAllAttachments = async (imageType) => {
  try {
    const attachments = getAttachments(imageType);
    for (const attachment of attachments) {
      await imageManager.deleteImage(attachment.id, true);
    }
    ElMessage.success('已清空');
  } catch (error) {
    ElMessage.error('清空失败');
  }
};

// 预览图片
const previewImage = (url) => {
  emit("preview-file", url, 'image/*');
};

// 上传错误处理
const handleUploadError = (error) => {
  console.error('上传错误:', error);
  ElMessage.error('上传失败');
};
</script>

<style scoped>
.upload-preview {
  width: 100%;
  height: 120px;
  border: 2px dashed #dcdfe6;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.upload-preview:hover {
  border-color: #409eff;
}

.upload-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

.upload-placeholder {
  text-align: center;
  color: #8c939d;
}

.upload-placeholder .el-icon {
  font-size: 40px;
  margin-bottom: 8px;
  display: block;
}

.upload-placeholder span {
  font-size: 12px;
  display: block;
}

.image-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 8px;
}

.image-count {
  font-size: 12px;
  color: #666;
}

.packing-list-upload {
  margin-bottom: 12px;
}

.upload-tip {
  font-size: 12px;
  color: #999;
  margin-top: 4px;
}

.file-list {
  border: 1px solid #ebeef5;
  border-radius: 4px;
  padding: 12px;
  background: #fafafa;
}

.file-list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid #ebeef5;
}

.attachment-list {
  max-height: 200px;
  overflow-y: auto;
}

.attachment-item {
  display: flex;
  align-items: center;
  padding: 8px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  margin-bottom: 8px;
  background: white;
}

.attachment-item:last-child {
  margin-bottom: 0;
}

.attachment-preview {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 12px;
  background: #f5f7fa;
  border-radius: 4px;
  cursor: pointer;
}

.attachment-preview .el-icon {
  font-size: 24px;
  color: #409eff;
}

.attachment-details {
  flex: 1;
  overflow: hidden;
}

.attachment-name {
  font-size: 14px;
  color: #303133;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.attachment-meta {
  display: flex;
  gap: 12px;
}

.attachment-meta span {
  font-size: 12px;
  color: #909399;
}
</style>