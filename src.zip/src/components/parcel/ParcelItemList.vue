<template>
  <!-- 第八行 -->
  <el-row :gutter="10">
    <el-col :span="24">
      <el-form-item label="Items">
        <el-button type="success" size="small" @click="handleAddItem"
          >+ Add Item</el-button
        >
      </el-form-item>
    </el-col>
  </el-row>

  <!-- 为每个item添加卡片容器 -->
  <div
    v-for="(item, index) in parcel.itemList"
    :key="index"
    class="item-card"
  >
    <!-- item标题 -->
    <div class="item-header">
      <span class="item-title">Item {{ index + 1 }}</span>
      <span class="item-index">#{{ index + 1 }}</span>
    </div>

    <!-- item内容 -->
    <el-row :gutter="12" class="item-content">
      <el-col :span="6">
        <el-form-item
          size="small"
          label="SellerPart#"
          label-width="90px"
          class="item-form-item"
        >
          <el-input
            placeholder="Input SellerPart#"
            v-model="item.sellerPart"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="MfrPart#"
          label-width="80px"
          class="item-form-item"
        >
          <el-input
            placeholder="Input MfrPart#"
            v-model="item.mfrPart"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="Item#"
          label-width="70px"
          class="item-form-item"
        >
          <el-input
            placeholder="Input Item#"
            v-model="item.itemNo"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="Qty"
          label-width="50px"
          class="item-form-item"
        >
          <el-input
            placeholder="Qty"
            v-model="item.qty"
            type="number"
            min="1"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>

      <el-col :span="6">
        <el-form-item
          size="small"
          label="Owner"
          label-width="70px"
          class="item-form-item"
        >
          <el-select
            v-model="item.ownerId"
            placeholder="Choose Owner"
            clearable
            style="width: 100%"
          >
            <el-option
              v-for="user in users"
              :key="user.userId"
              :label="user.name"
              :value="user.userId"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="Status"
          label-width="70px"
          class="item-form-item"
        >
          <el-select
            v-model="item.itemStatus"
            placeholder="Set Status"
            clearable
            style="width: 100%"
          >
            <el-option label="Inspecting" :value="0"></el-option>
            <el-option label="InStock" :value="1"></el-option>
            <el-option label="OutStock" :value="2"></el-option>
            <el-option label="Exception" :value="9"></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="Received Date"
          label-width="110px"
          class="item-form-item"
        >
          <el-date-picker
            v-model="item.receivedDate"
            type="date"
            placeholder="Set Date"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
            style="width: 100%"
            clearable
          ></el-date-picker>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="Send Date"
          label-width="90px"
          class="item-form-item"
        >
          <el-date-picker
            v-model="item.sendDate"
            type="date"
            placeholder="Set Date"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
            style="width: 100%"
            clearable
          ></el-date-picker>
        </el-form-item>
      </el-col>

      <el-col :span="6">
        <el-form-item
          size="small"
          label="Dealer Received"
          label-width="120px"
          class="item-form-item"
        >
          <el-date-picker
            v-model="item.dealerReceivedDate"
            type="date"
            placeholder="Set Date"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
            style="width: 100%"
            clearable
          ></el-date-picker>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="Original Order#"
          label-width="120px"
          class="item-form-item"
        >
          <el-input
            placeholder="Original Order#"
            v-model="item.originalOrder"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item
          size="small"
          label="Original Return#"
          label-width="120px"
          class="item-form-item"
        >
          <el-input
            placeholder="Original Return#"
            v-model="item.originalReturnNo"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="18">
        <el-form-item
          size="small"
          label="Customer Feedback"
          label-width="150px"
          class="item-form-item"
        >
          <el-input
            placeholder="Customer Feedback"
            v-model="item.customerFeedback"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>

      <!-- 删除按钮 -->
      <el-col :span="24">
        <div class="item-footer">
          <el-button
            type="danger"
            size="small"
            @click="handleDeleteItem(index)"
            plain
          >
            <el-icon><Delete /></el-icon> Delete Item {{ index + 1 }}
          </el-button>
        </div>
      </el-col>
    </el-row>
  </div>

  <!-- 空状态 -->
  <div v-if="!parcel.itemList || parcel.itemList.length === 0" class="item-empty">
    <el-icon><Box /></el-icon>
    <p>暂无商品明细，点击"Add Item"按钮添加</p>
  </div>
</template>

<script setup>
import { Delete, Box } from '@element-plus/icons-vue'

const props = defineProps({
  parcel: {
    type: Object,
    required: true
  },
  users: {
    type: Array,
    required: true,
    default: () => []
  }
})

const emit = defineEmits(['add-item', 'delete-item'])

const handleAddItem = () => {
  emit('add-item')
}

const handleDeleteItem = (index) => {
  emit('delete-item', index)
}
</script>

<style scoped>
.item-card {
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
  background-color: #f8f9fa;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
}

.item-card:hover {
  border-color: #409eff;
  background-color: #f0f7ff;
  box-shadow: 0 2px 12px rgba(64, 158, 255, 0.1);
  transition: all 0.3s ease;
}

.item-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 2px solid #e4e7ed;
}

.item-title {
  font-weight: 600;
  color: #303133;
  font-size: 16px;
}

.item-index {
  color: #606266;
  font-size: 14px;
  background: #e4e7ed;
  padding: 4px 10px;
  border-radius: 12px;
}

.item-form-item {
  margin-bottom: 10px;
}

.item-form-item :deep(.el-form-item__label) {
  font-weight: 500;
  color: #606266;
}

.item-content {
  padding: 0 5px;
}

.item-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 15px;
  padding-top: 15px;
  border-top: 1px dashed #dcdfe6;
}

.item-footer .el-button {
  border-radius: 4px;
}

.item-empty {
  text-align: center;
  padding: 30px;
  color: #909399;
  border: 1px dashed #dcdfe6;
  border-radius: 8px;
  background-color: #fafafa;
  margin-bottom: 16px;
}

.item-empty .el-icon {
  font-size: 48px;
  margin-bottom: 16px;
}

.item-card:nth-child(even) {
  background-color: #fcfcfc;
}

.item-card:nth-child(even):hover {
  background-color: #f0f7ff;
}
</style>