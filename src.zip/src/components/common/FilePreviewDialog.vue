<template>
  <el-dialog
    :model-value="visible"
    :title="title"
    class="preview-modal"
    width="80%"
    @update:model-value="handleVisibleChange"
    @close="handleClose"
  >
    <div class="preview-content">
      <!-- 图片预览 -->
      <img
        v-if="previewType.startsWith('image/')"
        :src="previewUrl"
        class="preview-image"
        alt="预览"
      />

      <!-- PDF预览 -->
      <iframe
        v-else-if="previewType === 'application/pdf'"
        :src="previewUrl"
        class="preview-pdf"
        frameborder="0"
      ></iframe>

      <!-- 其他文件类型 -->
      <div v-else class="unsupported-preview">
        <el-icon><Warning /></el-icon>
        <p>暂不支持预览此文件类型</p>
        <p>文件地址: {{ previewUrl }}</p>
      </div>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="handleClose">关闭</el-button>
        <el-button
          type="primary"
          @click="handleDownload"
          v-if="previewUrl"
        >
          下载文件
        </el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed } from 'vue'
import { Warning } from '@element-plus/icons-vue'

const props = defineProps({
  visible: {
    type: Boolean,
    required: true
  },
  previewUrl: {
    type: String,
    default: ''
  },
  previewType: {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['update:visible', 'close', 'download'])

const title = computed(() => {
  return props.previewType.startsWith('image/') ? '图片预览' : 'PDF预览'
})

const handleVisibleChange = (value) => {
  emit('update:visible', value)
}

const handleClose = () => {
  emit('update:visible', false)
  emit('close')
}

const handleDownload = () => {
  emit('download', props.previewUrl)
}
</script>

<style scoped>
/* 样式保持不变 */
</style>