import { ref, computed, watch } from 'vue'
import { ElMessage } from 'element-plus'
import * as imageManageApi from '@/api/imageManage'
import * as imageApi from '@/api/image'

export function useImageManage(parcel, currentUser, token) {
  // 图片状态管理
  const imageAttachments = ref([])
  const newUploadedImages = ref([])
  const imagesToDelete = ref([])
  const loading = ref(false)
  
  // 模块类型和记录ID
  const MODULE_TYPE = 'PARCEL'
  const recordId = computed(() => parcel.value?.parcelId)
  
  // 图片类型配置
  const IMAGE_TYPES = {
    PACKAGE_SENDER: 'PACKAGE_SENDER',
    PACKAGE_RECEIVER: 'PACKAGE_RECEIVER',
    PACKAGE_LABEL: 'PACKAGE_LABEL',
    PACKING_LIST: 'PACKING_LIST'
  }
  
  // 获取分组图片 - 修复：添加类型安全检查
  const loadGroupedImages = async () => {
    if (!recordId.value) return
    
    try {
      loading.value = true
      const response = await imageManageApi.getGroupedImages(MODULE_TYPE, recordId.value)
      
      if (response.code === 1) {
        // 修复：确保 response.data 是数组
        const data = response.data || []
        const attachmentsArray = Array.isArray(data) ? data : []
        
        imageAttachments.value = attachmentsArray
        // 更新parcel中的图片信息（向后兼容）
        updateParcelImages(attachmentsArray)
      }
    } catch (error) {
      console.error('加载图片失败:', error)
    } finally {
      loading.value = false
    }
  }
  
  // 向后兼容：将image_attachment数据映射到parcel字段 - 修复：添加全面的类型检查
  const updateParcelImages = (attachments) => {
    if (!parcel.value) return
    
    // 修复：确保 attachments 是数组
    let attachmentsArray = attachments
    if (!attachments) {
      attachmentsArray = []
    } else if (!Array.isArray(attachments)) {
      // 如果不是数组，尝试转换
      if (typeof attachments === 'object' && attachments !== null) {
        attachmentsArray = Object.values(attachments)
      } else {
        attachmentsArray = []
      }
    }
    
    console.log('updateParcelImages - 处理附件数据:', attachmentsArray)
    
    // 清空原有图片字段
    parcel.value.imgBySender = ''
    parcel.value.imgByReceiver = ''
    parcel.value.label = ''
    parcel.value.packingList = []
    
    // 根据图片类型分组 - 修复：安全遍历
    if (attachmentsArray.length > 0) {
      attachmentsArray.forEach(group => {
        // 修复：确保 group 存在且有 type 属性
        if (!group || typeof group !== 'object') return
        
        const type = group.type || group.imageType
        const images = group.images || []
        
        console.log(`处理图片组 - type: ${type}, images数量: ${images.length}`)
        
        if (images.length > 0 && Array.isArray(images)) {
          const firstImage = images[0]
          const imageUrl = firstImage?.imageUrl || firstImage?.url || ''
          
          if (imageUrl) {
            switch(type) {
              case 'PACKAGE_SENDER':
              case IMAGE_TYPES.PACKAGE_SENDER:
                parcel.value.imgBySender = imageUrl
                console.log('设置 imgBySender:', imageUrl)
                break
              case 'PACKAGE_RECEIVER':
              case IMAGE_TYPES.PACKAGE_RECEIVER:
                parcel.value.imgByReceiver = imageUrl
                console.log('设置 imgByReceiver:', imageUrl)
                break
              case 'PACKAGE_LABEL':
              case IMAGE_TYPES.PACKAGE_LABEL:
                parcel.value.label = imageUrl
                console.log('设置 label:', imageUrl)
                break
              case 'PACKING_LIST':
              case IMAGE_TYPES.PACKING_LIST:
                // 修复：确保 packingList 是数组格式
                const packingItems = images.map(img => ({
                  url: img.imageUrl || img.url || '',
                  name: img.originalName || img.name || '未知文件',
                  type: img.mimeType || img.type || 'image/jpeg'
                }))
                parcel.value.packingList = packingItems
                console.log('设置 packingList:', packingItems)
                break
              default:
                console.warn('未知的图片类型:', type)
            }
          }
        }
      })
    } else {
      console.log('没有找到图片附件记录')
    }
  }
  
  // 上传单个图片
  const uploadSingleImage = async (file, imageType) => {
    if (!recordId.value) {
      // 如果是新增包裹，先保存包裹获取ID
      const tempId = -1 // 临时ID，表示新增状态
      return uploadImageToServer(file, imageType, tempId)
    }
    return uploadImageToServer(file, imageType, recordId.value)
  }
  
  const uploadImageToServer = async (file, imageType, id) => {
    try {
      // 1. 检查数量限制
      await checkImageLimitBeforeUpload(imageType, id)
      
      // 2. 上传图片
      const response = await imageManageApi.uploadSingleImage(
        file, 
        MODULE_TYPE, 
        id, 
        imageType
      )
      
      if (response.code === 1) {
        const attachment = response.data
        
        // 添加到新上传图片列表
        newUploadedImages.value.push({
          id: attachment.id,
          imageType: imageType,
          file: file
        })
        
        // 如果是编辑状态且recordId存在，直接添加到imageAttachments
        if (recordId.value && recordId.value > 0) {
          imageAttachments.value.push(attachment)
          updateParcelImages(groupImages(imageAttachments.value))
        }
        
        ElMessage.success('图片上传成功')
        return attachment
      } else {
        throw new Error(response.msg || '上传失败')
      }
    } catch (error) {
      ElMessage.error(`上传失败: ${error.message}`)
      throw error
    }
  }
  
  // 检查图片数量限制
  const checkImageLimitBeforeUpload = async (imageType, recordId) => {
    try {
      await imageManageApi.checkImageLimit(MODULE_TYPE, recordId, imageType)
    } catch (error) {
      throw new Error(error.response?.data?.msg || '图片数量已达上限')
    }
  }
  
  // 删除图片
  const deleteImage = async (imageId, physicalDelete = false) => {
    try {
      if (physicalDelete) {
        await imageManageApi.deleteImagePhysically(imageId)
      } else {
        await imageManageApi.deleteImage(imageId)
      }
      
      // 从本地列表中移除
      const index = imageAttachments.value.findIndex(img => img.id === imageId)
      if (index !== -1) {
        imagesToDelete.value.push(imageId)
        imageAttachments.value.splice(index, 1)
        updateParcelImages(groupImages(imageAttachments.value))
      }
      
      ElMessage.success('图片删除成功')
      return true
    } catch (error) {
      ElMessage.error(`删除失败: ${error.message}`)
      throw error
    }
  }
  
  // 根据图片类型分组 - 修复：添加类型检查
  const groupImages = (images) => {
    if (!images || !Array.isArray(images)) {
      return []
    }
    
    const grouped = {}
    
    images.forEach(img => {
      if (!img) return
      
      const type = img.imageType
      if (type) {
        if (!grouped[type]) {
          grouped[type] = []
        }
        grouped[type].push(img)
      }
    })
    
    return Object.keys(grouped).map(type => ({
      type: type,
      images: grouped[type] || []
    }))
  }
  
  // 保存包裹时处理图片
  const handleSaveImages = async (parcelData) => {
    if (!parcelData.parcelId) return parcelData
    
    const result = {
      ...parcelData,
      // 添加图片处理相关信息
      _imageInfo: {
        keepImageIds: imageAttachments.value.map(img => img.id),
        newImages: newUploadedImages.value,
        deleteImageIds: imagesToDelete.value
      }
    }
    
    return result
  }
  
  // 清除图片状态
  const clearImageState = () => {
    newUploadedImages.value = []
    imagesToDelete.value = []
    imageAttachments.value = []
  }
  
  // 获取特定类型的图片
  const getImagesByType = (imageType) => {
    if (!Array.isArray(imageAttachments.value)) {
      return []
    }
    return imageAttachments.value.filter(img => img.imageType === imageType)
  }
  
  // 获取图片URL（兼容新旧系统）
  const getFullImageUrl = (url) => {
    if (!url) return ''
    if (url.startsWith('http')) return url
    // 确保URL以斜杠开头
    const formattedUrl = url.startsWith('/') ? url : `/${url}`
    return `http://localhost:8080${formattedUrl}`
  }
  
  // 上传处理器（兼容现有代码）
  const createUploadHandlers = () => {
    return {
      // 发送前图片
      imgBySender: createImageHandler(IMAGE_TYPES.PACKAGE_SENDER, 'imgBySender'),
      // 接收后图片
      imgByReceiver: createImageHandler(IMAGE_TYPES.PACKAGE_RECEIVER, 'imgByReceiver'),
      // 标签
      label: createImageHandler(IMAGE_TYPES.PACKAGE_LABEL, 'label'),
      // 打包单
      packingList: createPackingListHandler(),
      
      // 上传前验证
      beforeAvatarUpload: (file) => validateImageFile(file, 'img'),
      beforeLabelUpload: (file) => validateImageFile(file, 'label'),
      beforePackingListUpload: (file) => validateImageFile(file, 'packingList'),
      
      // 删除打包单文件
      deletePackingFile: (index) => {
        if (parcel.value.packingList && Array.isArray(parcel.value.packingList) && parcel.value.packingList[index]) {
          const file = parcel.value.packingList[index]
          // 查找对应的image_attachment记录
          const attachment = imageAttachments.value.find(img => 
            img.imageUrl === file.url
          )
          if (attachment) {
            deleteImage(attachment.id)
          }
          parcel.value.packingList.splice(index, 1)
        }
      }
    }
  }
  
  const createImageHandler = (imageType, fieldName) => {
    return async (response, uploadFile) => {
      try {
        if (response.code === 1) {
          const fileUrl = response.data?.imageUrl || response.data
          const file = uploadFile.raw || uploadFile
          
          if (fileUrl) {
            // 如果是编辑状态，使用新的图片管理API
            if (recordId.value && recordId.value > 0) {
              const attachment = await uploadSingleImage(file, imageType)
              parcel.value[fieldName] = attachment.imageUrl
            } else {
              // 新增状态，临时存储
              parcel.value[fieldName] = fileUrl
            }
            ElMessage.success('上传成功')
          }
        }
      } catch (error) {
        ElMessage.error('上传失败')
      }
    }
  }
  
  const createPackingListHandler = () => {
    return async (response, uploadFile) => {
      try {
        if (response.code === 1) {
          const fileUrl = response.data?.imageUrl || response.data
          const file = uploadFile.raw || uploadFile
          
          if (fileUrl) {
            // 如果是编辑状态，使用新的图片管理API
            if (recordId.value && recordId.value > 0) {
              const attachment = await uploadSingleImage(file, IMAGE_TYPES.PACKING_LIST)
              
              if (!Array.isArray(parcel.value.packingList)) {
                parcel.value.packingList = []
              }
              
              parcel.value.packingList.push({
                url: attachment.imageUrl,
                name: file.name,
                type: file.type
              })
            } else {
              // 新增状态
              if (!Array.isArray(parcel.value.packingList)) {
                parcel.value.packingList = []
              }
              
              parcel.value.packingList.push({
                url: fileUrl,
                name: file.name,
                type: file.type
              })
            }
            ElMessage.success('上传成功')
          }
        }
      } catch (error) {
        ElMessage.error('上传失败')
      }
    }
  }
  
  const validateImageFile = (file, fileType = 'img') => {
    console.log('验证文件:', file.name, fileType)
    
    let maxSize = 5 // MB
    let allowedTypes = []
    
    switch(fileType) {
      case 'img':
        allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp']
        maxSize = 5
        break
      case 'label':
        allowedTypes = ['image/jpeg', 'image/png', 'application/pdf']
        maxSize = 10
        break
      case 'packingList':
        allowedTypes = ['image/jpeg', 'image/png', 'application/pdf']
        maxSize = 10
        break
    }
    
    // 检查文件类型
    const isValidType = allowedTypes.includes(file.type) || 
                       (fileType === 'label' && file.name.toLowerCase().endsWith('.pdf')) ||
                       (fileType === 'packingList' && file.name.toLowerCase().endsWith('.pdf'))
    
    if (!isValidType) {
      ElMessage.error(`不支持的文件类型: ${file.type}`)
      return false
    }
    
    // 检查文件大小
    const isLtMaxSize = file.size / 1024 / 1024 < maxSize
    if (!isLtMaxSize) {
      ElMessage.error(`文件大小不能超过${maxSize}MB`)
      return false
    }
    
    return true
  }
  
  // 监听recordId变化，加载图片
  watch(recordId, (newId) => {
    if (newId && newId > 0) {
      loadGroupedImages()
    } else {
      clearImageState()
    }
  }, { immediate: true })
  
  return {
    // 状态
    imageAttachments,
    newUploadedImages,
    imagesToDelete,
    loading,
    
    // 方法
    loadGroupedImages,
    uploadSingleImage,
    deleteImage,
    handleSaveImages,
    clearImageState,
    getImagesByType,
    getFullImageUrl,
    
    // 上传处理器
    createUploadHandlers,
    
    // 图片类型常量
    IMAGE_TYPES
  }
}