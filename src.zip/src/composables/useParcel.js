import { ref } from 'vue'
import {
  queryPageApi,
  addApi,
  queryInfoApi,
  updateApi,
  deleteApi,
} from "@/api/parcel"
import { ElMessage } from "element-plus"

export function useParcel(searchParams, currentPage, pageSize, currentUser) {
  const parcelList = ref([])
  const total = ref(0)

  // 搜索包裹列表
  const search = async () => {
    const result = await queryPageApi(
      searchParams.value.packageNo,
      searchParams.value.status,
      searchParams.value.processId,
      searchParams.value.beginProcessDate,
      searchParams.value.endProcessDate,
      searchParams.value.owner,
      searchParams.value.beginCreateDate,
      searchParams.value.endCreateDate,
      searchParams.value.itemNo,
      searchParams.value.sellerPart,
      searchParams.value.sender,
      searchParams.value.beginSendDate,
      searchParams.value.endSendDate,
      searchParams.value.receiver,
      searchParams.value.beginReceivedDate,
      searchParams.value.endReceivedDate,
      currentPage.value,
      pageSize.value
    )

    if (result?.code === 1) {
      parcelList.value = result.data?.rows || []
      total.value = result.data?.total || 0
    } else {
      parcelList.value = []
      total.value = 0
    }
  }

  // 获取包裹详情
  const getParcelDetail = async (parcelId) => {
    const result = await queryInfoApi(parcelId)
    if (result.code && result.data) {
      const data = result.data
      
      // 处理打包单数据
      if (data.packingList && Array.isArray(data.packingList)) {
        data.packingList = data.packingList.map((url) => ({
          url: url,
          name: url.split("/").pop(),
          type: url.toLowerCase().endsWith(".pdf")
            ? "application/pdf"
            : "image/*",
        }))
      }

      // 清理后端返回的空字符串日期
      if (data.itemList && data.itemList.length > 0) {
        data.itemList.forEach((item) => {
          const dateFields = ["receivedDate", "sendDate", "dealerReceivedDate"]
          dateFields.forEach((field) => {
            if (item[field] === "") {
              item[field] = null
            }
          })
        })
      }

      return data
    }
    return null
  }

  // 保存包裹
  const saveParcel = async (parcelData) => {
    const saveData = {
      ...parcelData,
      packingList: parcelData.packingList
        ? parcelData.packingList.map((file) => file.url)
        : [],
    }

    let result
    if (parcelData.parcelId) {
      result = await updateApi(saveData)
    } else {
      result = await addApi(saveData)
    }

    return result
  }

  // 删除包裹
  const deleteParcel = async (parcelId) => {
    const result = await deleteApi(parcelId)
    return result
  }

  return {
    parcelList,
    total,
    search,
    getParcelDetail,
    saveParcel,
    deleteParcel
  }
}
