import { computed } from 'vue'
import { useImageManage } from "./useImageManage"

export function useFileUpload(parcel, token, currentUser) {
  const BASE_URL = 'http://localhost:8080'

  // 使用新的图片管理逻辑
  const imageManager = useImageManage(parcel, currentUser, token)

  // 创建上传处理器
  const uploadHandlers = computed(() => {
    console.log('创建上传处理器, parcel:', parcel.value)
    return imageManager.createUploadHandlers()
  })

  // 获取完整图片URL
  const getFullImageUrl = (url) => {
    return imageManager.getFullImageUrl(url)
  }

  // 添加调试函数来检查图片URL
  const checkImageUrls = () => {
    console.log('=== 图片URL调试信息 ===')
    console.log('图片附件列表:', imageManager.imageAttachments.value)
    console.log('parcel.imgBySender:', parcel.value.imgBySender)
    console.log('parcel.imgByReceiver:', parcel.value.imgByReceiver)
    console.log('parcel.label:', parcel.value.label)
    console.log('parcel.packingList:', parcel.value.packingList)
    console.log('新上传的图片:', imageManager.newUploadedImages.value)
    console.log('待删除的图片:', imageManager.imagesToDelete.value)
  }

  // 创建Element Plus上传组件的配置
  const createUploadConfig = (imageType) => {
    const currentToken = token.value
    const currentUserName = currentUser.value?.name || ''
    
    if (!currentToken) {
      console.error('无法创建上传配置：token为空')
      return null
    }

    return {
      // 上传地址（使用代理）
      action: '/api/image/manage/upload',
      
      // 认证头信息 - 关键修复
      headers: {
        'Authorization': `Bearer ${currentToken}`,
        'token': currentToken,
        'username': currentUserName,
        'Content-Type': 'multipart/form-data'
      },
      
      // 附加数据
      data: {
        moduleType: 'PARCEL',
        recordId: parcel.value?.parcelId || -1,
        imageType: imageType
      },
      
      // 其他配置
      withCredentials: true,
      timeout: 30000
    }
  }

  return {
    // 图片管理器
    imageManager,
    
    // 兼容原有接口
    uploadHandlers,
    getFullImageUrl,
    checkImageUrls,
    
    // 新增：上传配置生成函数
    createUploadConfig,
    
    // 上传头信息（保持兼容）
    uploadHeaders: computed(() => ({ 
      token: token.value, 
      username: currentUser.value?.name || ''
    })),
    
    // 错误处理
    handleUploadError: (error) => {
      console.error('上传错误:', error)
      if (error.response) {
        console.error('响应状态:', error.response.status)
        console.error('响应数据:', error.response.data)
      }
    }
  }
}